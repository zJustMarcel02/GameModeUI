# CoreUI

- A MiniCoreUI by AlexItz16

# Plugin Sneak Peak.
- Fly on
- Fly off
- Heal
- Feed
- GM Creative
- GM Adventure
- GM Spectator
- Vanish on
- Vanish off
- Show Server Plugins
# another stuff comming soon
# My mcpe server:
- IP: play.nspe.ml
- PORT: 19132
# https://discord.io/NspeNetwork
